<?php
  include("function.php");
   
  $conn = databaseConnect();
   
  if(isset($_GET["kelembapan"]))
  {
    $kelembapan = $_GET["kelembapan"];
    if ($kelembapan <= 40) {
      $status = "Normal";
      $aksi = "Mati";
    }
    elseif ($kelembapan >= 70) {
      $status = "Berpotensi longsor!";
      $aksi = "Nyala dan Bunyi";
    }
    elseif ($kelembapan > 40) {
      $status = "Siaga";
      $aksi = "Nyala";
    }

    // Simpan data yang diterima ke database
 
    $sql = "INSERT INTO arduino_data (kelembapan, status, aksi) VALUES ('".$kelembapan."', '".$status."', '".$aksi."')";
 
    if ($conn->query($sql) === TRUE) {
      //echoDebug("New record created successfully</br>");
    } else {
      echoDebug("Error: " . $sql . "<br>" . $conn->error);
    }
  }
  $conn->close();
?> 